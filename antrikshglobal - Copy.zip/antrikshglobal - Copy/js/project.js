///nav bar
const navbar= document.querySelector('.navbar');

window.addEventListener('scroll', () =>{
    console.log(scroll);
    if(scrollY>=100){
        navbar.classList.add('bg');
    }else{
        navbar.classList.remove('bg');
    }
})


// manu click
function home(){
   

}